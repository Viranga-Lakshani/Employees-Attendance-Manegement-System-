/**
 * server.js
 * Main Express server exposing a compact REST API.
 * Human-friendly routes and comments included.
 */
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// NOTE: For a production system, keep secrets out of source code.
// This sample uses a hard-coded secret for simplicity.
const JWT_SECRET = 'replace_this_with_a_strong_secret_in_prod';

// Utility: generate JWT token for a user
function createToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
}

// Middleware: authenticate requests that carry a Bearer token.
function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

/**
 * Register a new employee.
 * Body: { name, email, password }
 * Returns: { token, user }
 */
app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password are required' });
  const existing = db.prepare('SELECT * FROM employees WHERE email = ?').get(email);
  if (existing) return res.status(400).json({ error: 'Email already registered' });

  const password_hash = await bcrypt.hash(password, 10);
  const result = db.prepare('INSERT INTO employees (name, email, password_hash) VALUES (?, ?, ?)').run(name, email, password_hash);
  const user = db.prepare('SELECT id, name, email, role FROM employees WHERE id = ?').get(result.lastInsertRowid);
  const token = createToken(user);
  res.json({ token, user });
});

/**
 * Login route.
 * Body: { email, password } -> returns token and user
 */
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password are required' });

  const userRow = db.prepare('SELECT * FROM employees WHERE email = ?').get(email);
  if (!userRow) return res.status(400).json({ error: 'Invalid credentials' });

  const match = await bcrypt.compare(password, userRow.password_hash);
  if (!match) return res.status(400).json({ error: 'Invalid credentials' });

  const user = { id: userRow.id, name: userRow.name, email: userRow.email, role: userRow.role };
  const token = createToken(user);
  res.json({ token, user });
});

/**
 * Clock in / clock out.
 * POST /api/attendance
 * Body: { type: 'clock_in' | 'clock_out', note?: string }
 * Auth required.
 */
app.post('/api/attendance', authMiddleware, (req, res) => {
  const user = req.user;
  const { type, note } = req.body || {};
  if (!['clock_in','clock_out'].includes(type)) return res.status(400).json({ error: 'type must be clock_in or clock_out' });

  db.prepare('INSERT INTO attendance (employee_id, type, note) VALUES (?, ?, ?)').run(user.id, type, note || null);
  res.json({ success: true, message: 'Attendance recorded', recordedAt: new Date().toISOString() });
});

/**
 * List attendance records.
 * GET /api/attendance?employee_id=&from=&to=
 * Admins or the same employee can fetch records.
 */
app.get('/api/attendance', authMiddleware, (req, res) => {
  const user = req.user;
  const employeeId = req.query.employee_id ? Number(req.query.employee_id) : null;
  const from = req.query.from;
  const to = req.query.to;

  // If the user is not admin and requests other employee's records -> forbidden
  if (employeeId && employeeId !== user.id && user.role !== 'admin') {
    return res.status(403).json({ error: 'Not allowed' });
  }

  let sql = 'SELECT a.id, a.employee_id, e.name as employee_name, a.type, a.timestamp, a.note FROM attendance a JOIN employees e ON e.id = a.employee_id';
  const where = [];
  const params = [];

  if (employeeId) { where.push('a.employee_id = ?'); params.push(employeeId); }
  if (from) { where.push('a.timestamp >= ?'); params.push(from); }
  if (to) { where.push('a.timestamp <= ?'); params.push(to); }

  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY a.timestamp DESC LIMIT 1000';

  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

/**
 * Simple seed route to create an admin user if none exists (development convenience).
 * POST /api/seed-admin { name, email, password }
 */
app.post('/api/seed-admin', async (req, res) => {
  const existing = db.prepare("SELECT * FROM employees WHERE role = 'admin'").get();
  if (existing) return res.json({ message: 'Admin already exists' });
  const { name='Admin', email='admin@example.com', password='admin123' } = req.body || {};
  const password_hash = await bcrypt.hash(password, 10);
  db.prepare('INSERT INTO employees (name,email,password_hash,role) VALUES (?,?,?,?)').run(name, email, password_hash, 'admin');
  res.json({ message: 'Admin user created' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Attendance backend listening on port', PORT));
