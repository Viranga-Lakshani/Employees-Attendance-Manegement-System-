# Attendance Backend (Node + Express + SQLite)

Simple REST API for employee attendance management. Uses SQLite (better-sqlite3) for storage.
Features:
- Employee registration & login (bcrypt + JWT)
- Clock in / Clock out endpoints
- Attendance listing, export CSV (basic)
- Human-readable code with comments

To run:
1. cd backend
2. npm install
3. npm start
