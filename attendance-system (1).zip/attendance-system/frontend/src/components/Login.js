import React, { useState } from 'react';
import api from '../api';

/**
 * Login form component
 * - Allows register or login for simplicity.
 * - This is intentionally simple so you can understand and extend it.
 */
export default function Login({ onLogin }){
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  async function submit(e){
    e.preventDefault();
    setMessage('');
    try {
      if (isRegister) {
        const res = await api.post('/register', { name, email, password });
        onLogin(res.data);
      } else {
        const res = await api.post('/login', { email, password });
        onLogin(res.data);
      }
    } catch (err) {
      const msg = err?.response?.data?.error || err.message;
      setMessage(msg);
    }
  }

  return (
    <div style={{ maxWidth: 480 }}>
      <h2>{isRegister ? 'Register' : 'Login'}</h2>
      <form onSubmit={submit}>
        {isRegister && (
          <div>
            <label>Name</label><br/>
            <input value={name} onChange={e=>setName(e.target.value)} required />
          </div>
        )}
        <div>
          <label>Email</label><br/>
          <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required/>
        </div>
        <div>
          <label>Password</label><br/>
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" required/>
        </div>
        <div style={{ marginTop: 10 }}>
          <button type="submit">{isRegister ? 'Create account' : 'Log in'}</button>
          <button type="button" onClick={()=>setIsRegister(!isRegister)} style={{ marginLeft: 8 }}>
            {isRegister ? 'Have an account? Login' : 'Create account'}
          </button>
        </div>
        {message && <p style={{ color: 'red' }}>{message}</p>}
      </form>
    </div>
  );
}
