import React, { useState, useEffect } from 'react';
import api from '../api';

/**
 * Dashboard component:
 * - Clock in / Clock out
 * - List recent attendance
 * - Simple human-readable UI and comments for clarity
 */
export default function Dashboard({ user, onLogout }){
  const [records, setRecords] = useState([]);
  const [message, setMessage] = useState('');

  async function loadRecords(){
    try {
      const res = await api.get('/attendance', { params: { employee_id: user.id } });
      setRecords(res.data);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(()=> { loadRecords(); }, []);

  async function record(type){
    setMessage('');
    try {
      await api.post('/attendance', { type });
      setMessage('Recorded ' + type);
      await loadRecords();
    } catch (err) {
      setMessage('Error: ' + (err?.response?.data?.error || err.message));
    }
  }

  return (
    <div style={{ maxWidth: 800 }}>
      <div style={{ display: 'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <strong>{user.name}</strong> — <small>{user.email}</small>
        </div>
        <div>
          <button onClick={onLogout}>Logout</button>
        </div>
      </div>

      <div style={{ marginTop: 16 }}>
        <button onClick={()=>record('clock_in')}>Clock In</button>
        <button onClick={()=>record('clock_out')} style={{ marginLeft: 8 }}>Clock Out</button>
        <span style={{ marginLeft: 12 }}>{message}</span>
      </div>

      <h3 style={{ marginTop: 20 }}>Recent attendance</h3>
      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse' }}>
        <thead><tr><th>When</th><th>Type</th><th>Note</th></tr></thead>
        <tbody>
          {records.map(r=>(
            <tr key={r.id}>
              <td>{new Date(r.timestamp).toLocaleString()}</td>
              <td>{r.type}</td>
              <td>{r.note || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
