# Attendance Frontend (React)

A lightweight React frontend to interact with the backend.
Files:
- src/index.js
- src/App.js
- src/api.js
- src/components/Login.js
- src/components/Dashboard.js

This code is intentionally simple and human-readable.
